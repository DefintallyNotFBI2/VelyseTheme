namespace Example
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.velyseForm1 = new VelyseTheme.VelyseForm();
            this.velyseNumericButton1 = new VelyseTheme.VelyseNumericButton();
            this.velyseProgressBar1 = new VelyseTheme.VelyseProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.velyseControlBox1 = new VelyseTheme.VelyseControlBox();
            this.velyseRadioButton1 = new VelyseTheme.VelyseRadioButton();
            this.velyseComboBox1 = new VelyseTheme.VelyseComboBox();
            this.velyseCircularProgressBar1 = new VelyseTheme.VelyseCircularProgressBar();
            this.velyseCheckbox1 = new VelyseTheme.VelyseCheckbox();
            this.velyseTextBox1 = new VelyseTheme.VelyseTextBox();
            this.velyseButton1 = new VelyseTheme.VelyseButton();
            this.velyseTabControl1 = new VelyseTheme.VelyseTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.velyseForm1.SuspendLayout();
            this.velyseTabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // velyseForm1
            // 
            this.velyseForm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseForm1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseForm1.Controls.Add(this.label1);
            this.velyseForm1.Controls.Add(this.velyseNumericButton1);
            this.velyseForm1.Controls.Add(this.velyseProgressBar1);
            this.velyseForm1.Controls.Add(this.label2);
            this.velyseForm1.Controls.Add(this.velyseControlBox1);
            this.velyseForm1.Controls.Add(this.velyseRadioButton1);
            this.velyseForm1.Controls.Add(this.velyseComboBox1);
            this.velyseForm1.Controls.Add(this.velyseCircularProgressBar1);
            this.velyseForm1.Controls.Add(this.velyseCheckbox1);
            this.velyseForm1.Controls.Add(this.velyseTextBox1);
            this.velyseForm1.Controls.Add(this.velyseButton1);
            this.velyseForm1.Controls.Add(this.velyseTabControl1);
            this.velyseForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.velyseForm1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.velyseForm1.Location = new System.Drawing.Point(0, 0);
            this.velyseForm1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseForm1.Name = "velyseForm1";
            this.velyseForm1.Padding = new System.Windows.Forms.Padding(13, 86, 13, 11);
            this.velyseForm1.RoundCorners = VelyseTheme.VelyseForm.VLRoundCorner.Round;
            this.velyseForm1.Sizable = true;
            this.velyseForm1.Size = new System.Drawing.Size(1067, 554);
            this.velyseForm1.SmartBounds = true;
            this.velyseForm1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
            this.velyseForm1.TabIndex = 0;
            this.velyseForm1.Text = "velyseForm1";
            this.velyseForm1.Text_Font = new System.Drawing.Font("Segoe UI", 12F);
            this.velyseForm1.TextColor = System.Drawing.Color.White;
            this.velyseForm1.TopColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            // 
            // velyseNumericButton1
            // 
            this.velyseNumericButton1._Theme = VelyseTheme.VelyseNumericButton._ThemeChoose.Light;
            this.velyseNumericButton1.AddSubTextColor = System.Drawing.Color.Gray;
            this.velyseNumericButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.velyseNumericButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.velyseNumericButton1.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseNumericButton1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.velyseNumericButton1.ForeColor = System.Drawing.Color.Gray;
            this.velyseNumericButton1.Location = new System.Drawing.Point(635, 489);
            this.velyseNumericButton1.Maximum = ((long)(9999999));
            this.velyseNumericButton1.Minimum = ((long)(0));
            this.velyseNumericButton1.Name = "velyseNumericButton1";
            this.velyseNumericButton1.Size = new System.Drawing.Size(144, 30);
            this.velyseNumericButton1.TabIndex = 13;
            this.velyseNumericButton1.Text = "velyseNumericButton1";
            this.velyseNumericButton1.Value = ((long)(100));
            this.velyseNumericButton1.Valueperclick = ((long)(1));
            this.velyseNumericButton1.ValueTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            // 
            // velyseProgressBar1
            // 
            this.velyseProgressBar1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(26)))), ((int)(((byte)(28)))));
            this.velyseProgressBar1.Location = new System.Drawing.Point(402, 337);
            this.velyseProgressBar1.Max = 100;
            this.velyseProgressBar1.Min = 0;
            this.velyseProgressBar1.Name = "velyseProgressBar1";
            this.velyseProgressBar1.OutLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.velyseProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(156)))), ((int)(((byte)(215)))));
            this.velyseProgressBar1.ShowPercent = false;
            this.velyseProgressBar1.Size = new System.Drawing.Size(377, 46);
            this.velyseProgressBar1.TabIndex = 12;
            this.velyseProgressBar1.Text = "velyseProgressBar1";
            this.velyseProgressBar1.TextColor = System.Drawing.Color.White;
            this.velyseProgressBar1.Value = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(99)))), ((int)(((byte)(144)))));
            this.label2.Location = new System.Drawing.Point(630, 458);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 28);
            this.label2.TabIndex = 11;
            this.label2.Text = "Set tick speed";
            // 
            // velyseControlBox1
            // 
            this.velyseControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.velyseControlBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseControlBox1.EnableHoverHighlight = false;
            this.velyseControlBox1.EnableMaximizeButton = true;
            this.velyseControlBox1.EnableMinimizeButton = true;
            this.velyseControlBox1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseControlBox1.Location = new System.Drawing.Point(933, 0);
            this.velyseControlBox1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseControlBox1.Name = "velyseControlBox1";
            this.velyseControlBox1.Size = new System.Drawing.Size(100, 25);
            this.velyseControlBox1.TabIndex = 9;
            this.velyseControlBox1.Text = "velyseControlBox1";
            // 
            // velyseRadioButton1
            // 
            this.velyseRadioButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseRadioButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.velyseRadioButton1.Checked = false;
            this.velyseRadioButton1.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(104)))), ((int)(((byte)(160)))));
            this.velyseRadioButton1.ElipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.velyseRadioButton1.Location = new System.Drawing.Point(92, 474);
            this.velyseRadioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseRadioButton1.Name = "velyseRadioButton1";
            this.velyseRadioButton1.Size = new System.Drawing.Size(175, 22);
            this.velyseRadioButton1.TabIndex = 8;
            this.velyseRadioButton1.Text = "velyseRadioButton1";
            this.velyseRadioButton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // velyseComboBox1
            // 
            this.velyseComboBox1.AccentColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.velyseComboBox1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(23)))), ((int)(((byte)(25)))));
            this.velyseComboBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(23)))), ((int)(((byte)(25)))));
            this.velyseComboBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.velyseComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.velyseComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.velyseComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.velyseComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.velyseComboBox1.FormattingEnabled = true;
            this.velyseComboBox1.Location = new System.Drawing.Point(581, 283);
            this.velyseComboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseComboBox1.Name = "velyseComboBox1";
            this.velyseComboBox1.Size = new System.Drawing.Size(160, 27);
            this.velyseComboBox1.TabIndex = 6;
            this.velyseComboBox1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // velyseCircularProgressBar1
            // 
            this.velyseCircularProgressBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseCircularProgressBar1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseCircularProgressBar1.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.velyseCircularProgressBar1.ForeColor = System.Drawing.Color.White;
            this.velyseCircularProgressBar1.Location = new System.Drawing.Point(808, 346);
            this.velyseCircularProgressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseCircularProgressBar1.Maximum = ((long)(100));
            this.velyseCircularProgressBar1.MinimumSize = new System.Drawing.Size(133, 123);
            this.velyseCircularProgressBar1.Name = "velyseCircularProgressBar1";
            this.velyseCircularProgressBar1.OutLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.velyseCircularProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(156)))), ((int)(((byte)(215)))));
            this.velyseCircularProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(156)))), ((int)(((byte)(215)))));
            this.velyseCircularProgressBar1.ProgressShape = VelyseTheme.VelyseCircularProgressBar._ProgressShape.Round;
            this.velyseCircularProgressBar1.Size = new System.Drawing.Size(173, 173);
            this.velyseCircularProgressBar1.TabIndex = 5;
            this.velyseCircularProgressBar1.Text = "velyseCircularProgressBar1";
            this.velyseCircularProgressBar1.TextColor = System.Drawing.Color.White;
            this.velyseCircularProgressBar1.Value = ((long)(1));
            // 
            // velyseCheckbox1
            // 
            this.velyseCheckbox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(35)))));
            this.velyseCheckbox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.velyseCheckbox1.Checked = false;
            this.velyseCheckbox1.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(104)))), ((int)(((byte)(160)))));
            this.velyseCheckbox1.ElipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.velyseCheckbox1.Location = new System.Drawing.Point(93, 428);
            this.velyseCheckbox1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseCheckbox1.Name = "velyseCheckbox1";
            this.velyseCheckbox1.Size = new System.Drawing.Size(163, 22);
            this.velyseCheckbox1.TabIndex = 4;
            this.velyseCheckbox1.Text = "Stop Progressbars";
            this.velyseCheckbox1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.velyseCheckbox1.Click += new System.EventHandler(this.velyseCheckbox1_Click_1);
            // 
            // velyseTextBox1
            // 
            this.velyseTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.velyseTextBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.velyseTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseTextBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.velyseTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.velyseTextBox1.Image = null;
            this.velyseTextBox1.Location = new System.Drawing.Point(363, 493);
            this.velyseTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseTextBox1.MaxLength = 32767;
            this.velyseTextBox1.Multiline = false;
            this.velyseTextBox1.Name = "velyseTextBox1";
            this.velyseTextBox1.ReadOnly = false;
            this.velyseTextBox1.Size = new System.Drawing.Size(129, 46);
            this.velyseTextBox1.TabIndex = 2;
            this.velyseTextBox1.Text = "1";
            this.velyseTextBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.velyseTextBox1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.velyseTextBox1.UseSystemPasswordChar = false;
            this.velyseTextBox1.Click += new System.EventHandler(this.velyseTextBox1_Click);
            // 
            // velyseButton1
            // 
            this.velyseButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(26)))), ((int)(((byte)(28)))));
            this.velyseButton1.Location = new System.Drawing.Point(93, 321);
            this.velyseButton1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseButton1.MouseOver = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(132)))), ((int)(((byte)(165)))));
            this.velyseButton1.Name = "velyseButton1";
            this.velyseButton1.Size = new System.Drawing.Size(200, 62);
            this.velyseButton1.TabIndex = 1;
            this.velyseButton1.Text = "Start Progressbar";
            this.velyseButton1.TextColor = System.Drawing.Color.White;
            this.velyseButton1.VMouseDown = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(122)))), ((int)(((byte)(155)))));
            this.velyseButton1.Click += new System.EventHandler(this.velyseButton1_Click);
            // 
            // velyseTabControl1
            // 
            this.velyseTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.velyseTabControl1.Controls.Add(this.tabPage1);
            this.velyseTabControl1.Controls.Add(this.tabPage2);
            this.velyseTabControl1.FirstHeaderBorder = false;
            this.velyseTabControl1.ItemSize = new System.Drawing.Size(40, 180);
            this.velyseTabControl1.Location = new System.Drawing.Point(0, 75);
            this.velyseTabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.velyseTabControl1.Multiline = true;
            this.velyseTabControl1.Name = "velyseTabControl1";
            this.velyseTabControl1.SelectedIndex = 0;
            this.velyseTabControl1.SelectedTextColor = System.Drawing.Color.White;
            this.velyseTabControl1.Size = new System.Drawing.Size(1067, 186);
            this.velyseTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.velyseTabControl1.TabControlBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.velyseTabControl1.TabControlSideColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.velyseTabControl1.TabIndex = 0;
            this.velyseTabControl1.TabMouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.velyseTabControl1.TabSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(79)))), ((int)(((byte)(124)))));
            this.velyseTabControl1.unSelectedTextColor = System.Drawing.Color.Gray;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage1.ForeColor = System.Drawing.Color.White;
            this.tabPage1.Location = new System.Drawing.Point(184, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(879, 178);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.tabPage2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage2.ForeColor = System.Drawing.Color.White;
            this.tabPage2.Location = new System.Drawing.Point(184, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(879, 178);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(99)))), ((int)(((byte)(144)))));
            this.label1.Location = new System.Drawing.Point(302, 444);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 28);
            this.label1.TabIndex = 14;
            this.label1.Text = "Set Click Value (ONLY NUMBERS)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.velyseForm1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "velyseForm1";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.velyseForm1.ResumeLayout(false);
            this.velyseForm1.PerformLayout();
            this.velyseTabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private VelyseTheme.VelyseForm velyseForm1;
        private VelyseTheme.VelyseRadioButton velyseRadioButton1;
        private VelyseTheme.VelyseComboBox velyseComboBox1;
        private VelyseTheme.VelyseCircularProgressBar velyseCircularProgressBar1;
        private VelyseTheme.VelyseCheckbox velyseCheckbox1;
        private VelyseTheme.VelyseTextBox velyseTextBox1;
        private VelyseTheme.VelyseButton velyseButton1;
        private VelyseTheme.VelyseTabControl velyseTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private VelyseTheme.VelyseControlBox velyseControlBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private VelyseTheme.VelyseProgressBar velyseProgressBar1;
        private VelyseTheme.VelyseNumericButton velyseNumericButton1;
        private System.Windows.Forms.Label label1;
    }
}

